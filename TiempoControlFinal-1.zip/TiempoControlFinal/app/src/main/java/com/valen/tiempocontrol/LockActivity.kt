package com.valen.tiempocontrol

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

class LockActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        render()
    }

    private fun render() {
        val pkg = intent.getStringExtra("blocked_package") ?: ""
        val limit = intent.getIntExtra("limit", 0)
        val appName = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (_: Exception) { "Esta aplicación" }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(30, 30, 30, 30)
            setBackgroundColor(Color.rgb(18, 25, 39))
        }
        root.addView(TextView(this).apply {
            text = "TIEMPO CONTROL"
            textSize = 12f
            letterSpacing = .16f
            setTextColor(Color.rgb(157, 185, 240))
        })
        root.addView(TextView(this).apply {
            text = "Límite alcanzado"
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(0, 22, 0, 10)
        })
        root.addView(TextView(this).apply {
            text = appName
            textSize = 21f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(190, 205, 230))
            setPadding(0, 0, 0, 16)
        })
        root.addView(TextView(this).apply {
            text = "Ya utilizaste los $limit minutos diarios que configuraste. Podrás volver a entrar cuando se reinicie el contador del día."
            textSize = 16f
            gravity = Gravity.CENTER
            setLineSpacing(3f, 1f)
            setTextColor(Color.rgb(218, 224, 235))
        })
        setContentView(root)
    }
}
