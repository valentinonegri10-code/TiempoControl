package com.valen.tiempocontrol

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.os.Process
import java.util.Calendar

data class AppUsage(
    val packageName: String,
    val label: String,
    val minutes: Long,
    val limitMinutes: Int,
    val selected: Boolean
)

object UsageRepository {
    fun hasUsagePermission(context: Context): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return appOps.checkOpNoThrow(
            "android:get_usage_stats", Process.myUid(), context.packageName
        ) == AppOpsManager.MODE_ALLOWED
    }

    fun dayStart(): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    fun usageMillis(context: Context, packageName: String): Long {
        if (!hasUsagePermission(context)) return 0L
        val manager = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        return manager.queryAndAggregateUsageStats(dayStart(), System.currentTimeMillis())
            .getOrDefault(packageName, null)?.totalTimeInForeground ?: 0L
    }

    fun allApps(context: Context): List<AppUsage> {
        val prefs = context.getSharedPreferences("limits", Context.MODE_PRIVATE)
        val selected = prefs.getStringSet("tracked", emptySet()) ?: emptySet()
        val pm = context.packageManager
        return pm.getInstalledApplications(0)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null && it.packageName != context.packageName }
            .map { info ->
                val label = pm.getApplicationLabel(info).toString()
                AppUsage(
                    info.packageName, label,
                    usageMillis(context, info.packageName) / 60000L,
                    prefs.getInt("limit_${info.packageName}", 60),
                    selected.contains(info.packageName)
                )
            }
            .sortedByDescending { it.minutes }
    }

    fun totalMillis(context: Context): Long =
        allApps(context).sumOf { it.minutes } * 60000L

    fun format(ms: Long): String {
        val minutes = ms / 60000L
        val hours = minutes / 60L
        val rest = minutes % 60L
        return if (hours > 0) "${hours} h ${rest} min" else "${rest} min"
    }
}
