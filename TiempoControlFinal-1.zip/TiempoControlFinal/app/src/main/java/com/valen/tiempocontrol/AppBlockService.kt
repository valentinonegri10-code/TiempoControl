package com.valen.tiempocontrol

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class AppBlockService : AccessibilityService() {
    private var lastBlockedPackage: String? = null
    private var lastLaunchAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui") return

        val prefs = getSharedPreferences("limits", Context.MODE_PRIVATE)
        val tracked = prefs.getStringSet("tracked", emptySet()) ?: emptySet()
        if (pkg !in tracked) {
            lastBlockedPackage = null
            return
        }
        val limit = prefs.getInt("limit_$pkg", 60)
        if (limit <= 0) return

        val used = UsageRepository.usageMillis(this, pkg)
        if (used >= limit * 60_000L) {
            val now = System.currentTimeMillis()
            if (lastBlockedPackage != pkg || now - lastLaunchAt > 1500L) {
                lastBlockedPackage = pkg
                lastLaunchAt = now
                startActivity(Intent(this, LockActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    putExtra("blocked_package", pkg)
                    putExtra("limit", limit)
                })
            }
        } else {
            lastBlockedPackage = null
        }
    }

    override fun onInterrupt() {}
}
