package com.valen.tiempocontrol

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("limits", Context.MODE_PRIVATE) }
    private lateinit var content: LinearLayout
    private lateinit var usageLabel: TextView
    private lateinit var statusLabel: TextView

    private val navy = Color.rgb(18, 25, 39)
    private val blue = Color.rgb(48, 104, 220)
    private val ink = Color.rgb(30, 38, 52)
    private val muted = Color.rgb(111, 121, 138)
    private val bg = Color.rgb(244, 246, 250)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    override fun onResume() {
        super.onResume()
        if (::content.isInitialized) refresh()
    }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 30, 22, 22)
            setBackgroundColor(navy)
        }
        header.addView(TextView(this).apply {
            text = "TIEMPO CONTROL"
            textSize = 12f
            letterSpacing = .14f
            setTextColor(Color.rgb(167, 190, 235))
        })
        header.addView(TextView(this).apply {
            text = "Tu tiempo,
tu decisión."
            textSize = 29f
            setLineSpacing(0f, 1.05f)
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            setPadding(0, 10, 0, 8)
        })
        usageLabel = TextView(this).apply {
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }
        header.addView(usageLabel)
        statusLabel = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.rgb(198, 207, 222))
            setPadding(0, 6, 0, 0)
        }
        header.addView(statusLabel)
        root.addView(header)

        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 16, 18, 24)
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        refresh()
    }

    private fun refresh() {
        content.removeAllViews()
        val permission = UsageRepository.hasUsagePermission(this)
        val usages = if (permission) UsageRepository.allApps(this) else emptyList()
        val total = usages.sumOf { it.minutes } * 60000L
        usageLabel.text = "Uso de hoy: ${UsageRepository.format(total)}"
        val tracked = prefs.getStringSet("tracked", emptySet()) ?: emptySet()
        statusLabel.text = "${tracked.size} aplicaciones bajo control"

        if (!permission) {
            addSection("PRIMEROS PASOS")
            addCard {
                addText("Activá el acceso a los datos de uso para que la app pueda medir el tiempo por aplicación.", 14, ink)
                addButton("Conceder acceso al uso") {
                    startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                }
            }
        }
        addSection("BLOQUEO")
        addCard {
            addText("Para mostrar el bloqueo cuando se supera un límite, Android necesita que habilites el servicio de accesibilidad.", 14, ink)
            addButton("Configurar servicio de bloqueo") {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        addSection("APLICACIONES")
        if (!permission) {
            addText("Cuando habilites el permiso, acá aparecerán tus aplicaciones y sus estadísticas.", 14, muted)
            return
        }
        addText("Activá el interruptor de las apps que quieras controlar. El límite inicial es de 60 minutos diarios.", 13, muted)
        usages.forEach { app ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(14, 12, 14, 12)
                setBackgroundColor(Color.WHITE)
            }
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val labels = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
            }
            labels.addView(TextView(this).apply {
                text = app.label
                textSize = 16f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(ink)
            })
            labels.addView(TextView(this).apply {
                text = "Hoy: ${app.minutes} min" + if (app.selected) " · Límite: ${app.limitMinutes} min" else " · Sin límite"
                textSize = 12f
                setTextColor(muted)
                setPadding(0, 3, 0, 0)
            })
            line.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
            val toggle = Switch(this).apply {
                isChecked = app.selected
                setOnCheckedChangeListener { _, checked ->
                    val updated = (prefs.getStringSet("tracked", emptySet()) ?: emptySet()).toMutableSet()
                    if (checked) updated.add(app.packageName) else updated.remove(app.packageName)
                    prefs.edit().putStringSet("tracked", updated).apply()
                    if (checked && prefs.getInt("limit_${app.packageName}", 0) == 0) {
                        prefs.edit().putInt("limit_${app.packageName}", 60).apply()
                    }
                    refresh()
                }
            }
            line.addView(toggle)
            card.addView(line)
            if (app.selected) {
                val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                    max = 100
                    progress = if (app.limitMinutes > 0) ((app.minutes * 100) / app.limitMinutes).coerceAtMost(100).toInt() else 0
                    progressTintList = android.content.res.ColorStateList.valueOf(blue)
                    setPadding(0, 8, 0, 4)
                }
                card.addView(progress, LinearLayout.LayoutParams(-1, 12))
                card.addView(TextView(this).apply {
                    text = "${app.minutes} de ${app.limitMinutes} minutos"
                    textSize = 12f
                    setTextColor(muted)
                })
                val edit = Button(this).apply {
                    text = "Cambiar límite"
                    isAllCaps = false
                    setOnClickListener { editLimit(app.packageName, app.label, app.limitMinutes) }
                }
                card.addView(edit)
            }
            content.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 9 })
        }
    }

    private fun addSection(text: String) {
        content.addView(TextView(this).apply {
            this.text = text
            textSize = 12f
            letterSpacing = .1f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(muted)
            setPadding(0, 10, 0, 9)
        })
    }

    private fun addText(text: String, size: Int, color: Int) {
        content.addView(TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            setPadding(2, 4, 2, 10)
        })
    }

    private fun addCard(build: LinearLayout.() -> Unit) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 14, 14, 14)
            setBackgroundColor(Color.WHITE)
            build()
        }
        content.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })
    }

    private fun LinearLayout.addText(text: String, size: Int, color: Int) {
        addView(TextView(this@MainActivity).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            setPadding(0, 0, 0, 8)
        })
    }

    private fun LinearLayout.addButton(label: String, action: () -> Unit) {
        addView(Button(this@MainActivity).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
        })
    }

    private fun editLimit(pkg: String, label: String, current: Int) {
        val input = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText(current.toString())
            selectAll()
            hint = "Minutos por día"
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("Límite de $label")
            .setMessage("Ingresá el máximo de minutos por día.")
            .setView(input)
            .setPositiveButton("Guardar") { _, _ ->
                val value = input.text.toString().toIntOrNull()
                if (value != null && value in 1..1440) {
                    prefs.edit().putInt("limit_$pkg", value).apply()
                    refresh()
                } else {
                    Toast.makeText(this, "Usá un valor entre 1 y 1440 minutos.", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
