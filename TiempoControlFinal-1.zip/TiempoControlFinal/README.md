# Tiempo Control — proyecto Android

Versión 1.1 del proyecto personal para Android. Incluye panel de uso diario, listado de apps,
selección de aplicaciones a controlar, límites diarios y pantalla de bloqueo por límite superado.

## Estado
Es un proyecto fuente listo para abrir/compilar en Android Studio, pero todavía no es un APK
instalable ni fue probado en un teléfono físico. El bloqueo usa un servicio de accesibilidad y
es disuasorio, no inviolable.

## Permisos
1. Abrir la app y habilitar "Acceso a datos de uso".
2. Habilitar "Bloqueo de aplicaciones" en Ajustes > Accesibilidad > Aplicaciones instaladas.
3. Seleccionar las apps y configurar sus límites.

## Compatibilidad
- Android 8.0 o posterior (minSdk 26).
- Diseñado para compilar con Android Gradle Plugin 8.7.3 y SDK 35.

## Crear APK en la nube
Este repositorio incluye `.github/workflows/build-apk.yml`. Si se sube el proyecto a un repositorio
GitHub y se ejecuta la acción "Build Android APK", GitHub Actions compila el APK y lo ofrece como
artefacto descargable. Esto no requiere instalar Android Studio localmente, pero sí crear/subir un
repositorio GitHub y descargar el artefacto.

## Limitaciones técnicas conocidas
- Las estadísticas de Android pueden diferir ligeramente de Bienestar digital.
- El sistema puede retrasar la actualización del uso y los servicios de accesibilidad pueden ser
  detenidos por el fabricante o por ahorro de batería.
- El bloqueo puede desactivarse desde Ajustes; no es un bloqueo de nivel de sistema.
- Para un control más estricto se necesitaría Device Owner / administración del dispositivo,
  que requiere aprovisionamiento especial y no es adecuado para prometer un bloqueo infalible.
